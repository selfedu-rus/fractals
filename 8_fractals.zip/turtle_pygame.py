import pygame
import math

class TurtlePygame:
    def __init__(self, surf):
        self.surf = surf
        self.x = 0
        self.y = 0
        self.angle = 0
        self.penwidth = 1
        self.color = (0, 0, 0)
        self.fl_draw = True

    def tracer(self, a, b):
        pass

    def done(self):
        pass

    def ht(self):
        pass

    def pencolor(self, color):
        self.color = color

    def setpos(self, pos):
        self.x = pos[0]
        self.y = pos[1]

    def goto(self, x, y):
        self.setpos((x, y))

    def seth(self, angle):
        self.angle = angle

    def xcor(self):
        return self.x

    def ycor(self):
        return self.y

    def heading(self):
        return self.angle

    def up(self):
        self.fl_draw = False

    def down(self):
        self.fl_draw = True

    def pensize(self, width=None):
        if not width:
            return self.penwidth

        self.penwidth = width

    def fd(self, length):
        self.forward(length)

    def forward(self, length):
        x = self.x + length * math.cos(math.radians(self.angle))
        y = self.y - length * math.sin(math.radians(self.angle))
        if self.fl_draw:
            pygame.draw.line(self.surf, self.color, (round(self.x), round(self.y)), (round(x), round(y)), round(self.penwidth))
        self.x = x
        self.y = y

    def left(self, an):
        self.angle += an

    def right(self, an):
        self.angle -= an
